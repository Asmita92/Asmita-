﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DAL;
using DAL.DataProvider;

namespace ShoppingSite.UI.Admin.Product
{
    public partial class All : System.Web.UI.Page
    {
        BindDataManager _bindDataManager;


        //Constructor
        public All()
        {
            this._bindDataManager = new BindDataManager();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            //GridView_Products.DataSource = _bindDataManager.GetAllProducts();
            //GridView_Products.DataBind();
           

        }
    }
}