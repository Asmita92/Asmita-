﻿using BLL.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL.DataProvider;

namespace ShoppingSite.UI.Admin.Product
{
    public partial class AddVarients : System.Web.UI.Page
    {
        //BrandManager brandManager = new BrandManager();
        //CategoryManager categoryManager = new CategoryManager();
        //CurrencyManager currencyManager = new CurrencyManager();
        BindData bindData = new BindData();
        ProductManager productManager = new ProductManager();
        ProductVarientManager varientManager = new ProductVarientManager();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bindProducts();
                bindVarientTypes();
            }
        }

        protected void bindProducts()
        {
            ddlProduct.DataSource = productManager.SelectAll();
            ddlProduct.DataValueField = "Product_Id";
            ddlProduct.DataTextField = "Name";
            ddlProduct.DataBind();
        }

        protected void bindVarientTypes()
        {
            ddlVarient.DataSource = bindData.AllVarientTypes();
            ddlVarient.DataValueField = "Varient_Id";
            ddlVarient.DataTextField = "Varient_Name";
            ddlVarient.DataBind();
        }

        protected void btn_Save_Click(object sender, EventArgs e)
        {
            DAL.Product_Varient_Value varients = new DAL.Product_Varient_Value();

            varients.Product_Id = Convert.ToInt64(ddlProduct.SelectedValue);
            varients.Varient_Id = Convert.ToInt32(ddlVarient.SelectedValue);
            varients.Updated_By = "Asmita";
            varients.Last_Updated_Date = DateTime.Now;
            varients.Varient_Value = txt_VarientValue.Text.ToString();
            varientManager.Insert(varients);
            varientManager.Save();

            Response.Redirect("~/Admin/Product/All.aspx");
        }
    }
}