﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL.Manager;
using DAL;

namespace ShoppingSite.UI.Admin.Product
{
    public partial class Add : System.Web.UI.Page
    {
        BrandManager brandManager = new BrandManager();
        CategoryManager categoryManager = new CategoryManager();
        CurrencyManager currencyManager = new CurrencyManager();
        ProductManager productManager = new ProductManager();


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bindBrands();
                bindCategory();
                bindCurrency();
                bindPriceDecisionFactors();
            }
        }

        protected void bindBrands()
        {
            ddlBrand.DataSource = brandManager.SelectAll();
            ddlBrand.DataValueField = "Brand_Id";
            ddlBrand.DataTextField = "Name";
            ddlBrand.DataBind();
        }

        protected void bindCategory()
        {
            ddlCategory.DataSource = categoryManager.SelectAll();
            ddlCategory.DataValueField = "Category_Id";
            ddlCategory.DataTextField = "Name";
            ddlCategory.DataBind();
        }

        protected void bindCurrency()
        {
            ddlCurrency.DataSource = currencyManager.SelectAll();
            ddlCurrency.DataValueField = "Currency_Id";
            ddlCurrency.DataTextField = "Type";
            ddlCurrency.DataBind();
        }

        protected void bindPriceDecisionFactors()
        {
            ShoppingSiteEntities entities = new ShoppingSiteEntities();
            //string conStr = ConfigurationManager.ConnectionStrings["ShoppingConnectionString"].ToString();
            //SqlConnection con = new SqlConnection(conStr);
            //string com = "Select * from Price_Decision_Factor";
            //SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            //DataTable dt = new DataTable();
            //adpt.Fill(dt);
            ddlPriceDecisionFactor.DataSource = entities.Price_Decision_Factor.ToList();
            ddlPriceDecisionFactor.DataBind();
            ddlPriceDecisionFactor.DataTextField = "Decision_Factor";
            ddlPriceDecisionFactor.DataValueField = "Price_Decision_Factor_Id";
            ddlPriceDecisionFactor.DataBind();
        }

        protected void btnSub_Click(object sender, EventArgs e)
        {
            //if (!IsPostBack)
            //{
                DAL.Product product = new DAL.Product();

                product.Name = txt_product_name.Text.ToString();
                product.Currency_Id = Convert.ToInt64(ddlCurrency.SelectedValue);
                product.Price_Decision_Factor_Id = Convert.ToInt64(ddlPriceDecisionFactor.SelectedValue);
                product.MRP = Convert.ToDecimal(txt_MRP.Text);
                product.Our_Price = Convert.ToDecimal(txt_OUR_prise.Text);
                product.Discount = Convert.ToInt32(txt_Discount.Text);
                product.Brand_Id = Convert.ToInt64(ddlBrand.SelectedValue);
                product.Category_Id = Convert.ToInt64(ddlCategory.SelectedValue);
                product.SKU = txt_SKU.Text.ToString();
                product.Info = TextArea_Info.InnerHtml.ToString();
                product.Description = TextArea_Description.InnerHtml.ToString();
                product.Specification = TextArea_Specification.InnerHtml.ToString();
                product.Availability = Convert.ToBoolean(check_Availability.Checked.ToString());
                product.InStockQty = Convert.ToInt32(txt_InStockQty.Text);
                product.IsNewArrival = Convert.ToBoolean(check_NewArrival.Checked.ToString());
                product.IsBestSelling = Convert.ToBoolean(check_BestSelling.Checked.ToString());
                product.IsActive = true;
                product.Last_Updated_Date = DateTime.Now;
                string MainImagePath = Server.MapPath("~/Product/");


                string NewImageName = Guid.NewGuid().ToString() + Path.GetExtension(file_MainImage.PostedFile.FileName);
                file_MainImage.SaveAs(MainImagePath + NewImageName);
                product.MainImage = "~/Product/" + NewImageName.ToString();

                productManager.Insert(product);
                productManager.Save();

                Response.Redirect("~/Admin/Product/All.aspx");
            //}

              
        }
    }
}