﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using DAL.Service;
using BLL.Manager;

namespace ShoppingSite.UI.Admin
{
    public partial class Brand : System.Web.UI.Page
    {
        private BrandManager brandManager;
        public Brand()
        {
            this.brandManager = new BrandManager();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            GridViewBrand.DataSource = brandManager.SelectAll();
        }


    }
}