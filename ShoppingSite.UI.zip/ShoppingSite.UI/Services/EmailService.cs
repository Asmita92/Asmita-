﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;

namespace ShoppingSite.UI.Services
{
    //public class EmailService
    //{
    //    public async Task<string> SendEmail(string EmailAddress, string Message, string Subject)
    //    {
    //        var body = "<p>Dear " + EmailAddress + "</p><p> " + Message + "</p>";
    //        var message = new MailMessage();
    //        message.To.Add(new MailAddress(EmailAddress)); //replace with valid value
    //        message.Subject = Subject;
    //        //message.Body = string.Format(body, model.FromName, model.FromEmail, model.Message);
    //        message.Body = string.Format(body, "Online Shopping Mart", "Online Shopping Mart", "Alert from Online Shopping Mart");

    //        //smtpClient.Credentials = new System.Net.NetworkCredential("youremail@hotmail.com", "password");
    //        message.IsBodyHtml = true;
    //        using (var smtp = new SmtpClient())
    //            try
    //            {
    //                {
    //                    await smtp.SendMailAsync(message);
    //                    Console.WriteLine("Email Send Successfully");
    //                }
    //            }
    //            catch (Exception ex)
    //            {
    //                Console.WriteLine(ex.Message);

    //            }
    //        return null;
    //    }
    //}

    public class EmailService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            var smtp = new System.Net.Mail.SmtpClient();
            var mail = new System.Net.Mail.MailMessage();

            mail.IsBodyHtml = true;
            mail.From = new System.Net.Mail.MailAddress("asmitapandey@gmail.com", "Online Shopping Mart");
            mail.To.Add(message.Destination);
            mail.Subject = message.Subject;
            mail.Body = message.Body;

            smtp.Timeout = 1000;

            var t = Task.Run(() => smtp.SendAsync(mail, null));

            return t;

            // Plug in your email service here to send an email.
            //return Task.FromResult(0);

        }
    }
}