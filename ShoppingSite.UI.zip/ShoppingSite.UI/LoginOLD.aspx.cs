﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL.DataProvider;
using ShoppingSite.UI.Logic;
using BLL;
using BLL.Manager;

namespace ShoppingSite.UI
{
    public partial class LoginOLD : System.Web.UI.Page
    {
        UserActions userActions;
        UserDetailsManager userDetailsManager;
        string UserId;
       // string UserRole;

        public LoginOLD()
        {
            this.userActions = new UserActions();
            this.userDetailsManager = new UserDetailsManager();

            this.UserId = Request.Cookies["UserID"].Value;
        }

        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ShoppingConnectionString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (User.Identity.IsAuthenticated)
            {
                UserId = User.Identity.Name;
            }
          bool signed =  HttpContext.Current.Request.IsAuthenticated;

        }

        //protected void btn_submit_Click(object sender, EventArgs e)
        //{
        //    SqlCommand cmd = new SqlCommand("select * from login_data", conn);
        //    conn.Open();
        //    if (conn.State == ConnectionState.Open)
        //    {
        //        SqlDataReader sdr = cmd.ExecuteReader();
        //        while (sdr.Read())
        //        {
        //            if (sdr[6].ToString().Equals(txtusername.Text) && sdr[2].ToString().Equals(txtpassword.Text))
        //            {
        //                Response.Cookies["uname"].Value = sdr[1].ToString();
        //                Response.Cookies["u_id"].Value = sdr[0].ToString();
        //                Session["Role"] = sdr[3].ToString();
        //                FormsAuthentication.RedirectFromLoginPage(txtusername.Text, false);
        //                Response.Redirect("~/Default.aspx");

        //            }
        //            else
        //            {
        //                lblerror.Text = "Your Username and Password is incorrect. Please try again later.";
        //            }

        //        }

        //    }

        //    else
        //    {
        //        lblerror.Text = "Unable to connect to database. Please try again later.";
        //    }
        //}
       
        protected void btn_submit_Click(object sender, EventArgs e)
        {
            var UserName = txtusername.Text.Trim().ToString();
            var Password = txtpassword.Text.Trim().ToString();

            if(UserName != null && Password != null)
            {
               bool checkLogin = userActions.CheckUserLogin(UserId, UserName, Password);
                if(checkLogin == true)
                {
                    Response.Cookies["UserName"].Value = UserName;
                    Response.Cookies["UserID"].Value = UserId;
                    Session["Role"] = userActions.GetUserRole(UserId).ToString();

                    FormsAuthentication.SetAuthCookie(UserName, true);

                    FormsAuthentication.RedirectFromLoginPage(txtusername.Text, false);
                    Response.Redirect("~/Default.aspx");
                }
                //userActions.CheckUserLogin()
            }
            else
            {
                lblerror.Text = "Unable to connect to database. Please try again later.";
            }
        }
    }
}