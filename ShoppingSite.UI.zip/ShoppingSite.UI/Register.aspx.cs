﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingSite.UI
{
    public partial class Register : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void CreateUser_Click(object sender, EventArgs e)
        {
            // Default UserStore constructor uses the default connection string named: DefaultConnection
            var userStore = new UserStore<IdentityUser>();
            var manager = new UserManager<IdentityUser>(userStore);

            var user = new IdentityUser() { UserName = UserName.Text, Email = Email.Text.Trim(), EmailConfirmed = true, PhoneNumber = PhoneNo.Text };
            IdentityResult result = manager.Create(user, Password.Text);

            //Uncomment this code if needed to 
            //send user to the same login page and dont login user after registering 
            //if (result.Succeeded)
            //{
            //    StatusMessage.Text = string.Format("User {0} was created successfully!", user.UserName);
            //}


            //Code to 
            //log in the user when registration succeeds. 
            //code implemented from Microsoft Official Blog 
            // https://docs.microsoft.com/en-us/aspnet/identity/overview/getting-started/adding-aspnet-identity-to-an-empty-or-existing-web-forms-project
            if (result.Succeeded)
            {
                // var authenticationManager = HttpContext.Current.GetOwinContext().Authentication;
                var authenticationManager = HttpContext.Current.GetOwinContext().Authentication;
                var userIdentity = manager.CreateIdentity(user, DefaultAuthenticationTypes.ApplicationCookie);
                authenticationManager.SignIn(new AuthenticationProperties() { }, userIdentity);
                Response.Redirect("~/Login.aspx");
            }
            else
            {
                StatusMessage.Text = result.Errors.FirstOrDefault();
            }
        }
    }
}