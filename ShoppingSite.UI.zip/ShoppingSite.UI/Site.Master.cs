﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using BLL.Manager;
using ShoppingSite.UI.Logic;
using Microsoft.AspNet.Identity;

namespace ShoppingSite.UI
{
    public partial class SiteMaster : MasterPage
    {
        CategoryManager categoryManager;
        ProductManager productManager;

        public SiteMaster()
        {
            this.categoryManager = new CategoryManager();
            this.productManager = new ProductManager();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            Page.PreLoad += master_Page_PreLoad;
            if (HttpContext.Current.User.IsInRole("Admin"))
            {
               // adminLink.Visible = true;
            }

        }

        protected void master_Page_PreLoad(object sender, EventArgs e)
        {
            
        }


        protected void Page_PreRender(object sender, EventArgs e)
        {
            using (ShoppingCartActions usersShoppingCart = new ShoppingCartActions())
            {
                string cartStr = string.Format("Cart ({0})", usersShoppingCart.GetCount());
                cartCount.InnerText = cartStr;
            }
        }

        public IQueryable<Product_Category> GetCategories()
        {
            IQueryable<Product_Category> query = categoryManager.SelectAll().AsQueryable();
            return query;
        }

        protected void Unnamed_LoggingOut(object sender, LoginCancelEventArgs e)
        {
            Context.GetOwinContext().Authentication.SignOut();
        }

        protected void img_shopping_chart_Click(object sender, ImageClickEventArgs e)
        {
            string u_id = "";
            try
            {
                u_id = Request.Cookies["u_id"].Value;
            }
            catch
            { }

            Response.Redirect("~/add_cart.aspx?u_id=" + u_id);

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Admin.aspx");
        }

        protected void btn_Img_search_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("~/Pages/Search_Results.aspx?Search=" + txtSearch.Text);
        }

        protected void btn_Edit_Profile_Click(object sender, EventArgs e)
        {


            Response.Redirect("~/Edit_Profile.aspx");
        }
    }
}