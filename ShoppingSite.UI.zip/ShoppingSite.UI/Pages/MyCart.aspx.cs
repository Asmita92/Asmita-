﻿using BLL.Manager;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;

namespace ShoppingSite.UI.Pages
{
    public partial class MyCart : System.Web.UI.Page
    {
        MyCartManager myCartManager;
        ProductManager productManager;
        UserDetailsManager userDetailsManager;
        ShoppingSiteEntities _entities;

        string UserId;


        public MyCart()
        {
            this.myCartManager = new MyCartManager();
            this.productManager = new ProductManager();
            this.userDetailsManager = new UserDetailsManager();
            this._entities = new ShoppingSiteEntities();
            //this.UserId = Request.Cookies["UserID"].Value;
            this.UserId = User.Identity.GetUserId();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
        //    GridViewMyCart.DataSource = myCartManager.SelectAll().Where(x => x.UserId == UserId).ToList();
        //    GridViewMyCart.DataBind();
        }

       
    }
}