﻿using BLL.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace ShoppingSite.UI.Logic
{
   public class UserActions
    {
        MyCartManager myCartManager;
        ProductManager productManager;
        UserDetailsManager userDetailsManager;
        ShoppingSiteEntities _entities;
        public UserActions()
        {
            this.myCartManager = new MyCartManager();
            this.productManager = new ProductManager();
            this.userDetailsManager = new UserDetailsManager();
            this._entities = new ShoppingSiteEntities();
        }

        public bool IsUserExists(string UserId)
        {
            var currentUser = userDetailsManager.SelectByID(UserId);
            if(currentUser!= null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CheckUserLogin(string UserId, string Username, string Password)
        {
            var currentUser = userDetailsManager.SelectByID(UserId);

            if (currentUser != null)
            {
                if (currentUser.Username.Equals(Username) && currentUser.Password.Equals(Password))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public string GetUserRole(string UserId)
        {
            var userDetails = userDetailsManager.SelectByID(UserId);
            var userRoleId = userDetails.UserRole_Id;

            var RoleName = _entities.UserRoles.Find(userRoleId);
            return RoleName.ToString();
        }
    }
}
