﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BLL;
using BLL.Manager;
using System.Web;
using Microsoft.AspNet.Identity;

namespace ShoppingSite.UI.Logic
{
    public class ShoppingCartActions : IDisposable
    {
        public string ShoppingCartId { get; set; }



        public string CartSessionKey = "CartId";
       // public string CartSessionKey = String.Empty;


        MyCartManager myCartManager;
        ProductManager productManager;
        UserDetailsManager userDetailsManager;
        string Username = String.Empty;

        public ShoppingCartActions()
        {
            this.myCartManager = new MyCartManager();
            this.productManager = new ProductManager();
            this.userDetailsManager = new UserDetailsManager();
        }

        public struct ShoppingCartUpdates
        {
            public int ProductId;
            public int PurchaseQuantity;
            public bool RemoveItem;
        }


        //public void AddToCart(int ProductId, decimal Price, int Quantity, string UserId)
        //{
        //    var cartItem = myCartManager.SelectByID(ProductId);
        //    if (cartItem == null)
        //    {
        //        Cart carts = new Cart();
        //        carts.Product_Id = ProductId;
        //        carts.Quantity = Quantity;
        //        carts.Price = Price;
        //        carts.UserId = UserId;
        //        myCartManager.Insert(carts);
        //    }
        //    else
        //    {
        //        cartItem.Quantity++;
        //    }
        //    myCartManager.Save();
        //}

        public void Dispose()
        {
            if (myCartManager != null)
            {
                // myCartManager.dis
                myCartManager = null;
            }
        }

        /// <summary>
        /// Generate new ShoppingCartId if the user is not logged in
        /// If user is logged in CartItem will be users email for tracking whose items are in cart 
        /// </summary>
        /// <returns></returns>
        public string GetCartId()
        {
            //if(HttpContext.Current.User.Identity.IsAuthenticated == false)
            //{
            //    HttpContext.Current.Session[CartSessionKey] = "Cart"
            //}
            if (HttpContext.Current.User.Identity.IsAuthenticated)
            {
                if (!string.IsNullOrWhiteSpace(HttpContext.Current.User.Identity.Name))
                {
                    HttpContext.Current.Session[CartSessionKey] = HttpContext.Current.User.Identity.GetUserId();
                }
                else
                {
                    // Generate a new random GUID using System.Guid class.     
                    Guid tempCartId = Guid.NewGuid();
                    //set CartSessionKey with generated GUID
                    HttpContext.Current.Session[CartSessionKey] = tempCartId.ToString();
                }
            }
            else
            {
                // Generate a new random GUID using System.Guid class.     
                Guid tempCartId = Guid.NewGuid();
                //set CartSessionKey with generated GUID
                HttpContext.Current.Session[CartSessionKey] = tempCartId.ToString();
            }
            return HttpContext.Current.Session[CartSessionKey].ToString();
        }

        /// <summary>
        /// return all items in cart of current user.
        /// </summary>
        /// <returns></returns>
        public List<CartItem> GetCartItems()
        {
            ShoppingCartId = GetCartId();
            var items = myCartManager.SelectAll().Where(c => c.CartId == ShoppingCartId).ToList();
            return items;
        }

        /// <summary>
        /// Get Total Price in Shopping cart of User
        /// </summary>
        /// <returns></returns>
        public decimal GetTotal()
        {
            ShoppingCartId = GetCartId();
            // Multiply product price by quantity of that product to get        
            // the current price for each of those products in the cart.  
            // Sum all product price totals to get the cart total.   
            decimal? total = decimal.Zero;
            total = (decimal?)(from cartItems in myCartManager.SelectAll()
                               where cartItems.CartId == ShoppingCartId
                               select (int?)cartItems.Quantity *
                               cartItems.Product.Our_Price).Sum();
            return total ?? decimal.Zero;
        }


        public void AddToCart(long Product_ID)
        {
            // Retrieve the product from the database.           
            ShoppingCartId = GetCartId();

            //check if user has already that item in Shopping Cart
            //If user has already the product in shopping Cart then update the quantity of the item by 1
            var cartItem = myCartManager.SelectAll().Where(c => c.CartId == ShoppingCartId
            && c.Product_Id == Product_ID).FirstOrDefault();

            if (cartItem == null)
            {
                //If Product is not added yet in Shopping Cart, add the product in users Shopping Cart.
                cartItem = new CartItem
                {
                    Product_Id = Product_ID,
                    CartId = ShoppingCartId,
                    //Product = productManager.SelectByID(Product_ID),
                    Quantity = 1,
                    AddedOn = DateTime.Now
                };
                myCartManager.Insert(cartItem);
                myCartManager.Save();
            }
            else
            {
                // If the item does exist in the cart,                  
                // then add one to the quantity.                 
                cartItem.Quantity++;
            }
            myCartManager.Save();
        }



        public ShoppingCartActions GetCart(HttpContext context)
        {
            using (var cart = new ShoppingCartActions())
            {
                cart.ShoppingCartId = cart.GetCartId();
                return cart;
            }
        }

        public void UpdateShoppingCartDatabase(String cartId, ShoppingCartUpdates[] CartItemUpdates)
        {
            try
            {
                int CartItemCount = CartItemUpdates.Count();
                List<CartItem> myCart = GetCartItems();
                foreach (var cartItem in myCart)
                {
                    // Iterate through all rows within shopping cart list
                    for (int i = 0; i < CartItemCount; i++)
                    {
                        if (cartItem.Product.Product_Id == CartItemUpdates[i].ProductId)
                        {
                            if (CartItemUpdates[i].PurchaseQuantity < 1 || CartItemUpdates[i].RemoveItem == true)
                            {
                                RemoveItem(cartId, cartItem.Product_Id);
                            }
                            else
                            {
                                UpdateItem(cartId, cartItem.Product_Id, CartItemUpdates[i].PurchaseQuantity);
                            }
                        }
                    }
                }
            }
            catch (Exception exp)
            {
                throw new Exception("ERROR: Unable to Update Cart Database - " + exp.Message.ToString(), exp);
            }
        }

        public void RemoveItem(string removeCartID, long removeProductID)
        {
            try
            {
                var myItem = (from c in myCartManager.SelectAll()
                              where c.CartId == removeCartID 
                              && c.Product.Product_Id == removeProductID
                              select c).FirstOrDefault();
                if (myItem != null)
                {
                    myCartManager.Delete(myItem);
                    myCartManager.Save();
                }
            }
            catch (Exception exp)
            {
                throw new Exception("ERROR: Unable to Remove Cart Item - " + exp.Message.ToString(), exp);
            }
        }

        public void UpdateItem(string updateCartID, long updateProductID, int quantity)
        {
            try
            {
                var myItem = (from c in myCartManager.SelectAll()
                              where c.CartId == updateCartID 
                              && c.Product.Product_Id == updateProductID
                              select c).FirstOrDefault();
                if (myItem != null)
                {
                    myItem.Quantity = quantity;
                    myCartManager.Save();
                }
            }
            catch (Exception exp)
            {
                throw new Exception("ERROR: Unable to Update Cart Item - " + exp.Message.ToString(), exp);
            }
        }



        public void RemoveItem(int ProductId)
        {
            try
            {
                var removeProduct = myCartManager.SelectByID(ProductId);

                if (removeProduct != null)
                {
                    myCartManager.Delete(ProductId);
                    myCartManager.Save();
                }
            }
            catch (Exception exp)
            {
                throw new Exception("ERROR: Unable to Remove item from Cart. Error Code: " + exp.Message.ToString(), exp);
            }

        }

        public void UpdateItem(int ProductID, int quantity)
        {
            try
            {
                //Cart cart = new Cart();
                var updateProduct = myCartManager.SelectByID(ProductID);
                //Get price of Selected Product
                int price = Convert.ToInt32(productManager.SelectByID(ProductID).MRP);
                if (updateProduct != null)
                {
                    updateProduct.Quantity = quantity;
                    //Update price of selected Product based on new Quantity
                    updateProduct.Price = Convert.ToDecimal(price * quantity);

                    //Update CartTable
                    myCartManager.Update(updateProduct);
                    myCartManager.Save();

                }
            }
            catch (Exception exp)
            {
                throw new Exception("ERROR: Unable to Update Cart Item. Error Code: " + exp.Message.ToString(), exp);
            }
        }

        public void EmptyCart()
        {
            ShoppingCartId = GetCartId();
            var cartItems = myCartManager.SelectAll()
                .Where(c => c.CartId == ShoppingCartId);
            foreach (var cartItem in cartItems)
            {

                myCartManager.Delete(cartItem);
            }
            // Save changes.             
            myCartManager.Save();
        }

        public int GetCount()
        {
            ShoppingCartId = GetCartId();

            // Get the count of each item in the cart and sum them up          
            int? count = (from cartItems in myCartManager.SelectAll()
                          where cartItems.CartId == ShoppingCartId
                          select (int?)cartItems.Quantity).Sum();
            // Return 0 if all entries are null         
            return count ?? 0;
        }

        public void MigrateCart(string cartId, string userName)
        {
            var shoppingCart = myCartManager.SelectAll().Where(c => c.CartId == cartId);
            foreach (CartItem item in shoppingCart)
            {
                item.CartId = userName;
            }
            HttpContext.Current.Session[CartSessionKey] = userName;
            myCartManager.Save();
        }
    }
}

