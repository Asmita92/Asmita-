﻿using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using DAL.DataProvider;
using BLL.Manager;
using ShoppingSite.UI.Logic;
using ShoppingSite.UI.Models;
using Microsoft.AspNet.Identity;

namespace ShoppingSite.UI.Account
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        UserDetailsManager userDetailsManager;
        ShoppingSiteEntities _entities;

        public ForgetPassword()
        {
            this.userDetailsManager = new UserDetailsManager();
            this._entities = new ShoppingSiteEntities();
        }


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_ForgotNEW(object sender, EventArgs e)
        {
            if (IsValid)
            {
                
                var Email = EmailAddress.Text;

               
                if (String.IsNullOrWhiteSpace(Email))
                {
                    FailureText.Text = "Please enter valid email.";
                    ErrorMessage.Visible = true;
                    return;
                }
                else
                {
                    Session["ResetPassword_Email"] = Email;
                    Response.Redirect("~/Account/ResetPasswordConfirmation.aspx");
                }
            }
        }

        protected void btn_Forgot(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Validate the user's email address
                var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();
                ApplicationUser user = manager.FindByName(EmailAddress.Text);
                if (user == null || !manager.IsEmailConfirmed(user.Id))
                {
                    FailureText.Text = "The user either does not exist or is not confirmed.";
                    ErrorMessage.Visible = true;
                    return;
                }
                // For more information on how to enable account confirmation and password reset please visit http://go.microsoft.com/fwlink/?LinkID=320771
                // Send email with the code and the redirect to reset password page
                string code = manager.GeneratePasswordResetToken(user.Id);
                string callbackUrl = IdentityHelper.GetResetPasswordRedirectUrl(code, Request);
                manager.SendEmail(user.Id, "Reset Password", "Please reset your password by clicking <a href=\"" + callbackUrl + "\">here</a>.");
                loginForm.Visible = false;
                DisplayEmail.Visible = true;
                Label_TestForgetPasswordCode.Text = "Please reset your password by clicking <a href=\"" + callbackUrl + "\">here</a>.";
                Label_TestForgetPasswordCode.Visible = true;

            }
        }
    }
}