﻿using ShoppingSite.UI.PaymentModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using BLL.Manager;
using Microsoft.AspNet.Identity;

namespace ShoppingSite.UI.Checkout
{
    public partial class ShippingDetails : System.Web.UI.Page
    {
        IPaymentSystem paymentSystem = INFT3050PaymentFactory.Create();
        ShoppingSiteEntities _entities = new ShoppingSiteEntities();


        protected void Page_Load(object sender, EventArgs e)
        {           

           
        }
        protected void test()
        {
            if (Session["Payment_Amount"] != null)
            {
                string amt = Session["Payment_Amount"].ToString();

                PaymentRequest payment = new PaymentRequest();

                payment.CardName = "Arthur Anderson";
                payment.CardNumber = "4444333322221111";
                payment.CVC = 123;
                payment.Expiry = new DateTime(2020, 11, 1);
                payment.Amount = 200;
                payment.Description = "Payment made by " + User.Identity.Name;
                var task = paymentSystem.MakePayment(payment);
                // Checking result: 
                //if (task.IsCompleted)
                //{
                //    showTransactionResult(task.Result);
                //}
            }
            else
            {
                Response.Redirect("CheckoutError.aspx?ErrorCode=AmtMissing");
            }
        }

        protected void SubmitShipping_Click(object sender, EventArgs e)
        {
            var TotalPriceNow = Session["Payment_Amount"].ToString();
            Order order = new Order();
            order.FullName = FirstName.Text + LastName.Text;
            order.DeliveryAddress = "Address: " + Address.Text
                + "City: " + City.Text
                + "State: " + State.Text
                + "Postal Code: " + PostalCode;

            order.Mobile = MobileNo.Text;
            order.TotalPrice = Convert.ToDecimal(TotalPriceNow);
            order.UserId = User.Identity.GetUserId();

            _entities.Orders.Add(order);
            _entities.SaveChanges();


        }
    }
}