﻿using ShoppingSite.UI.PaymentModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using BLL.Manager;
using Microsoft.AspNet.Identity;


namespace ShoppingSite.UI.Checkout
{
    public partial class Confirmation : System.Web.UI.Page
    {
        ShoppingSiteEntities _entities = new ShoppingSiteEntities();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                IPaymentSystem paymentSystem = INFT3050PaymentFactory.Create();
                if (Session["Payment_Amount"] != null)
                {
                    string amt = Session["Payment_Amount"].ToString();

                    PaymentRequest payment = new PaymentRequest();

                    payment.CardName = "Arthur Anderson";
                    payment.CardNumber = "4444333322221111";
                    payment.CVC = 123;
                    payment.Expiry = new DateTime(2020, 11, 1);
                    payment.Amount = 200;
                    payment.Description = "Payment made by " + User.Identity.Name;
                    var task = paymentSystem.MakePayment(payment);
                    // Checking result: 
                    //if (task.IsCompleted)
                    //{
                    //    showTransactionResult(task.Result);
                    //}


                }




                // Get the shopping cart items and process them.
                using (ShoppingSite.UI.Logic.ShoppingCartActions usersShoppingCart = new ShoppingSite.UI.Logic.ShoppingCartActions())
                {
                    List<CartItem> myOrderList = usersShoppingCart.GetCartItems();

                    long OrderID = _entities.Orders.Where(x => x.UserId == User.Identity.GetUserId()).SingleOrDefault().Order_ID;
                    // Add OrderDetail information to the DB for each product purchased.
                    for (int i = 0; i < myOrderList.Count; i++)
                    {
                        // Create a new OrderDetail object.
                        var myOrderDetail = new OrderDetail();

                        myOrderDetail.Order_ID = OrderID;
                        myOrderDetail.UserId = User.Identity.GetUserId();
                        myOrderDetail.Product_Id = myOrderList[i].Product_Id;
                        myOrderDetail.Quantity = myOrderList[i].Quantity;
                        myOrderDetail.UnitPrice = myOrderList[i].Product.Our_Price;


                        // Add OrderDetail to DB.
                        _entities.OrderDetails.Add(myOrderDetail);
                        _entities.SaveChanges();
                    }

                    // Set OrderId.
                    Session["currentOrderId"] = OrderID;

                    // Display Order information.
                    //List<Order> orderList = new List<Order>();
                    //orderList.Add(myOrder);
                    //ShipInfo.DataSource = orderList;
                    //ShipInfo.DataBind();

                    //// Display OrderDetails.
                    //OrderItemList.DataSource = myOrderList;
                    //OrderItemList.DataBind();
                }
            }
            else
            {
                Response.Redirect("CheckoutError.aspx?");
            }
        }
        protected void CheckoutConfirm_Click(object sender, EventArgs e)
        {
            Session["userCheckoutCompleted"] = "true";
            Response.Redirect("~/Checkout/CheckoutComplete.aspx");
        }

    }

}