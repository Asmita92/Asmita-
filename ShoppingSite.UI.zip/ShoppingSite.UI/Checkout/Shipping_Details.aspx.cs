﻿using DAL;
using Microsoft.AspNet.Identity;
using ShoppingSite.UI.Logic;
using ShoppingSite.UI.PaymentModule;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ShoppingSite.UI.Checkout
{
    public partial class Shipping_Details : System.Web.UI.Page
    {
        ShoppingCartActions usersShoppingCart = new ShoppingCartActions();

        IPaymentSystem paymentSystem = INFT3050PaymentFactory.Create();
        ShoppingSiteEntities _entities = new ShoppingSiteEntities();
        string cartId;

        protected void Page_Load(object sender, EventArgs e)
        {
            cartId  = usersShoppingCart.GetCartId();
        }

        protected void SubmitShipping_Click(object sender, EventArgs e)
        {
            var TotalPriceNow = Session["Payment_Amount"].ToString();
            Order order = new Order();
            order.FullName = FirstName.Text + LastName.Text;
            order.DeliveryAddress = "Address: " + Address.Text
                + "City: " + City.Text
                + "State: " + State.Text
                + "Country: " + Country;

            order.Mobile = MobileNo.Text;
            order.TotalPrice = Convert.ToDecimal(TotalPriceNow);
            //order.UserId = User.Identity.GetUserId();
            order.UserId = cartId;
            _entities.Orders.Add(order);
            _entities.SaveChanges();


        }

        
    }
}