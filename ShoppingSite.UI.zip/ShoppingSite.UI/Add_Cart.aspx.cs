﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL;
using BLL.Manager;
using DAL.Service;
using ShoppingSite.UI.Logic;
using System.Diagnostics;
using Microsoft.AspNet.Identity;

namespace ShoppingSite.UI
{
    public partial class Add_Cart : System.Web.UI.Page
    {      
        ShoppingCartActions shoppingCartActions;
        public Add_Cart()
        {
            this.shoppingCartActions = new ShoppingCartActions();
        }

        // SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ShoppingConnectionString"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {
            string productId = Request.QueryString["ProductID"];

            //string price = Request.QueryString["Price"];
            //string qty = Request.QueryString["Quantity"];

            //Only Use when not using Microsoft Identity for webforms
            //  string UserId = Request.Cookies["UserID"].Value;sssssssssss
            //string UserId = User.Identity.GetUserId();


            if (!String.IsNullOrEmpty(productId))
            {
                shoppingCartActions.AddToCart(Convert.ToInt32(productId));
            }
            else
            {
                Response.Redirect("ShoppingCart.aspx");
            }
            Response.Redirect("ShoppingCart.aspx");
        }

        protected void btn_place_order_Click(object sender, ImageClickEventArgs e)
        {
            //int u_id = Convert.ToInt32(Request.Cookies["u_id"].Value);
            //string product_id = "";
            //conn.Open();
            //string query = "SELECT STUFF((    SELECT ','+ [product_id] AS [text()] FROM [Shopping].[dbo].[cart_product]  WHERE [user_id] = '" + u_id + "' FOR XML PATH('') ), 1, 1,'')";
            //SqlCommand cmd = new SqlCommand(query, conn);
            //var result = cmd.ExecuteScalar();
            //if (!Convert.IsDBNull(result))
            //    product_id = (string)result;
            //conn.Close();

            //Response.Redirect("~/OrderSummary.aspx?product_id=" + product_id);

        }
    }
}