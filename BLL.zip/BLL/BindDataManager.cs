﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Generic;
using DAL.DataProvider;

namespace BLL
{
   public class BindDataManager
    {
        private BindData bindData;
        

        public BindDataManager()
        {
            this.bindData = new BindData();
        }

        public IEnumerable<View_Products> GetAllProducts()
        {
            return this.bindData.AllProducts();
        }
    }
}
