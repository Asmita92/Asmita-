﻿using DAL;
using DAL.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Manager
{
   
    public class MyCartManager
    {
        private MyCartService myCartService;

        public MyCartManager()
        {
            this.myCartService = new MyCartService();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<CartItem> SelectAll()
        {
            return this.myCartService.SelectAll().ToList();
        }

        public CartItem SelectByID(object id)
        {
            return this.myCartService.SelectByID(id);
        }

        public void Insert(CartItem obj)
        {
            this.myCartService.Insert(obj);
        }


        public void Update(CartItem obj)
        {
            this.myCartService.Update(obj);
        }


        public void Delete(object id)
        {
            this.myCartService.Delete(id);
        }

        public void Save()
        {
            this.myCartService.Save();
        }
    }
}
