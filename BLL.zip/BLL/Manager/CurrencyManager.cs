﻿using DAL;
using DAL.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.Manager
{
    public class CurrencyManager
    {
        private CurrencyService currencyService;

        public CurrencyManager()
        {
            this.currencyService = new CurrencyService();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Currency_Master> SelectAll()
        {
            return this.currencyService.SelectAll().ToList();
        }

        public Currency_Master SelectByID(object id)
        {
            return this.currencyService.SelectByID(id);
        }

        public void Insert(Currency_Master obj)
        {
            this.currencyService.Insert(obj);
        }


        public void Update(Currency_Master obj)
        {
            this.currencyService.Update(obj);
        }


        public void Delete(object id)
        {
            this.currencyService.Delete(id);
        }

        public void Save()
        {
            this.currencyService.Save();
        }
    }
}
