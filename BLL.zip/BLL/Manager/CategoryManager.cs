﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Service;
using DAL;

namespace BLL.Manager
{
    public class CategoryManager
    {
        private CategoryService categoryService;

        public CategoryManager()
        {
            this.categoryService = new CategoryService();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product_Category> SelectAll()
        {
            return this.categoryService.SelectAll().ToList();
        }

        public Product_Category SelectByID(object id)
        {
            return this.categoryService.SelectByID(id);
        }

        public void Insert(Product_Category obj)
        {
            this.categoryService.Insert(obj);
        }


        public void Update(Product_Category obj)
        {
            this.categoryService.Update(obj);
        }


        public void Delete(object id)
        {
            this.categoryService.Delete(id);
        }

        public void Save()
        {
            this.categoryService.Save();
        }
    }
}
