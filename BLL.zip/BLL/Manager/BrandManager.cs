﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using DAL.Service;

namespace BLL.Manager
{
    public class BrandManager
    {
        private BrandService brandService;

        public BrandManager()
        {
            this.brandService = new BrandService();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product_Brand> SelectAll()
        {
            return this.brandService.SelectAll().ToList();
        }

        public Product_Brand SelectByID(object id)
        {
            return this.brandService.SelectByID(id);
        }

        public void Insert(Product_Brand obj)
        {
            this.brandService.Insert(obj);
        }


        public void Update(Product_Brand obj)
        {
            this.brandService.Update(obj);
        }


        public void Delete(object id)
        {
            this.brandService.Delete(id);
        }

        public void Save()
        {
            this.brandService.Save();
        }
    }
}
