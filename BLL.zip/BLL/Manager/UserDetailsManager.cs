﻿using DAL.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL.Manager
{
    public class UserDetailsManager
    {
        private UserManagerServices userManagerService;

        public UserDetailsManager()
        {
            this.userManagerService = new UserManagerServices();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<UserDetail> SelectAll()
        {
            return this.userManagerService.SelectAll().ToList();
        }

        public UserDetail SelectByID(object id)
        {
            return this.userManagerService.SelectByID(id);
        }

        public void Insert(UserDetail obj)
        {
            this.userManagerService.Insert(obj);
        }


        public void Update(UserDetail obj)
        {
            this.userManagerService.Update(obj);
        }


        public void Delete(object id)
        {
            this.userManagerService.Delete(id);
        }

        public void Save()
        {
            this.userManagerService.Save();
        }
    }
}
