﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Service;
using DAL;

namespace BLL.Manager
{
    
    public class ProductVarientManager
    {
        private ProductVarientService varientService;

        public ProductVarientManager()
        {
            this.varientService = new ProductVarientService();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product_Varient_Value> SelectAll()
        {
            return this.varientService.SelectAll().ToList();
        }

        public Product_Varient_Value SelectByID(object id)
        {
            return this.varientService.SelectByID(id);
        }

        public void Insert(Product_Varient_Value obj)
        {
            this.varientService.Insert(obj);
        }


        public void Update(Product_Varient_Value obj)
        {
            this.varientService.Update(obj);
        }


        public void Delete(object id)
        {
            this.varientService.Delete(id);
        }

        public void Save()
        {
            this.varientService.Save();
        }
    }
}
