﻿using DAL.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;

namespace BLL.Manager
{
    public class ProductManager
    {
        private ProductService productService;

        public ProductManager()
        {
            this.productService = new ProductService();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product> SelectAll()
        {
            return this.productService.SelectAll().ToList();
        }

        public Product SelectByID(object id)
        {
            return this.productService.SelectByID(id);
        }

        public void Insert(Product obj)
        {
            this.productService.Insert(obj);
        }


        public void Update(Product obj)
        {
            this.productService.Update(obj);
        }


        public void Delete(object id)
        {
            this.productService.Delete(id);
        }

        public void Save()
        {
            this.productService.Save();
        }
    }
}
