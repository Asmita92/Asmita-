﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Service
{
    public class MyCartService
    {
        private IGenericRepository<CartItem> repository;

        public MyCartService()
        {
            this.repository = new GenericRepository<CartItem>();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<CartItem> SelectAll()
        {
            return this.repository.SelectAll().ToList();
        }
        public CartItem SelectByID(object id)
        {
            return this.repository.SelectByID(id);
        }
        public void Insert(CartItem obj)
        {
            this.repository.Insert(obj);
        }


        public void Update(CartItem obj)
        {
            this.repository.Update(obj);
        }


        public void Delete(object id)
        {
            this.repository.Delete(id);
        }

        public void Save()
        {
            this.repository.Save();
        }
    }
}
