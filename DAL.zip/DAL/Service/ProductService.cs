﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Service
{
    public class ProductService
    {
        private IGenericRepository<Product> repository;

        public ProductService()
        {
            this.repository = new GenericRepository<Product>();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product> SelectAll()
        {
            return this.repository.SelectAll().ToList();
        }
        public Product SelectByID(object id)
        {
            return this.repository.SelectByID(id);
        }
        public void Insert(Product obj)
        {
            this.repository.Insert(obj);
        }


        public void Update(Product obj)
        {
            this.repository.Update(obj);
        }


        public void Delete(object id)
        {
            this.repository.Delete(id);
        }

        public void Save()
        {
            this.repository.Save();
        }
    }
}
