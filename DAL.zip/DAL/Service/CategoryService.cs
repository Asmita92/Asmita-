﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Service
{
    public class CategoryService
    {
        private IGenericRepository<Product_Category> repository;

        public CategoryService()
        {
            this.repository = new GenericRepository<Product_Category>();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product_Category> SelectAll()
        {
            return this.repository.SelectAll().ToList();
        }

        public Product_Category SelectByID(object id)
        {
            return this.repository.SelectByID(id);
        }
        public void Insert(Product_Category obj)
        {
            this.repository.Insert(obj);
        }


        public void Update(Product_Category obj)
        {
            this.repository.Update(obj);
        }


        public void Delete(object id)
        {
            this.repository.Delete(id);
        }

        public void Save()
        {
            this.repository.Save();
        }
    }
}
