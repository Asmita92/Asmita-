﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Generic;
using DAL;

namespace DAL.Service
{
  public  class BrandService
    {
        private IGenericRepository<Product_Brand> repository;

        public BrandService()
        {
            this.repository = new GenericRepository<Product_Brand>();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product_Brand> SelectAll()
        {
            return this.repository.SelectAll().ToList();
        }
        public Product_Brand SelectByID(object id)
        {
            return this.repository.SelectByID(id);
        }
        public void Insert(Product_Brand obj)
        {
            this.repository.Insert(obj);
        }


        public void Update(Product_Brand obj)
        {
            this.repository.Update(obj);
        }


        public void Delete(object id)
        {
            this.repository.Delete(id);
        }

        public void Save()
        {
            this.repository.Save();
        }
    }
}
