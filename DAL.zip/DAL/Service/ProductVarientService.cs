﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Service
{
    public class ProductVarientService
    {
        private IGenericRepository<Product_Varient_Value> repository;

        public ProductVarientService()
        {
            this.repository = new GenericRepository<Product_Varient_Value>();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<Product_Varient_Value> SelectAll()
        {
            return this.repository.SelectAll().ToList();
        }
        public Product_Varient_Value SelectByID(object id)
        {
            return this.repository.SelectByID(id);
        }
        public void Insert(Product_Varient_Value obj)
        {
            this.repository.Insert(obj);
        }


        public void Update(Product_Varient_Value obj)
        {
            this.repository.Update(obj);
        }


        public void Delete(object id)
        {
            this.repository.Delete(id);
        }

        public void Save()
        {
            this.repository.Save();
        }
    }
}
