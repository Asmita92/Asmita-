﻿using DAL.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Service
{
    public class UserManagerServices
    {
        private IGenericRepository<UserDetail> repository;

        public UserManagerServices()
        {
            this.repository = new GenericRepository<UserDetail>();
        }

        //Servce Methods to pass data from Generic Repo to Manager of BLL
        public IEnumerable<UserDetail> SelectAll()
        {
            return this.repository.SelectAll().ToList();
        }
        public UserDetail SelectByID(object id)
        {
            return this.repository.SelectByID(id);
        }

        public void Insert(UserDetail obj)
        {
            this.repository.Insert(obj);
        }


        public void Update(UserDetail obj)
        {
            this.repository.Update(obj);
        }


        public void Delete(object id)
        {
            this.repository.Delete(id);
        }

        public void Save()
        {
            this.repository.Save();
        }
    }
}
