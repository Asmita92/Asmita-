﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataProvider
{
  public  class BindData
    {
        private ShoppingSiteEntities _entities;
        View_Products _viewProducts;

        public BindData()
        {
            this._entities = new ShoppingSiteEntities();
            this._viewProducts = new View_Products();
        }

        public IEnumerable<View_Products> AllProducts()
        {
            return this._entities.View_Products.ToList();
        }

        public View_Products GetProductById(Int64 ID)
        {
            return this._entities.View_Products.Where(x => x.Product_Id == ID).FirstOrDefault();
           // return this._entities.View_Products.Find(ID);
        }

        public IEnumerable<View_Products> ProductsByBrand(string BrandName)
        {
            var brandName = BrandName.Trim().ToString();
            return this._entities.View_Products.Where(x => x.Brand == brandName).ToList();
        }

        public IEnumerable<View_Products> ProductsByCategory(string CategoryName)
        {
            var categoryName = CategoryName.Trim().ToString();
            return this._entities.View_Products.Where(x => x.Category == categoryName).ToList();
        }

        public IEnumerable<M_Product_Varients> AllVarientTypes()
        {
            return this._entities.M_Product_Varients.ToList();
        }

        public IEnumerable<View_ProductVarient> AllProductVarients()
        {
            return this._entities.View_ProductVarient.ToList();
        }
    }
}
